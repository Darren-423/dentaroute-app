import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  ActivityIndicator, FlatList, KeyboardAvoidingView, Platform,
  StyleSheet,
  Text, TextInput, TouchableOpacity,
  View,
} from "react-native";
import { ChatMessage, store } from "../../lib/store";

const T = {
  teal: "#0f766e",
  tealLight: "#14b8a6",
  bg: "#f8fafc",
  white: "#fff",
  text: "#0f172a",
  textSec: "#64748b",
  textMuted: "#94a3b8",
  border: "#e2e8f0",
};

export default function DoctorChatScreen() {
  const { chatRoomId, patientName } = useLocalSearchParams<{
    chatRoomId: string; patientName: string;
  }>();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const flatListRef = useRef<FlatList>(null);

  // Translation state
  const [translateOn, setTranslateOn] = useState(true);
  const [translatingIds, setTranslatingIds] = useState<Set<string>>(new Set());
  const [failedIds, setFailedIds] = useState<Set<string>>(new Set());
  const translatingRef = useRef(false);

  useEffect(() => {
    if (chatRoomId) {
      loadMessages();
      store.markAsRead(chatRoomId, "doctor");
    }
  }, [chatRoomId]);

  useEffect(() => {
    const interval = setInterval(loadMessages, 2000);
    return () => clearInterval(interval);
  }, [chatRoomId]);

  const loadMessages = async () => {
    if (!chatRoomId) return;
    const msgs = await store.getMessages(chatRoomId);
    setMessages(msgs);
    store.markAsRead(chatRoomId, "doctor");
  };

  // Auto-translate untranslated messages (batch: parallel API calls, single storage write)
  const translatePending = useCallback(async (msgs: ChatMessage[]) => {
    if (!translateOn || !chatRoomId || translatingRef.current) return;
    const needTranslation = msgs.filter((m) => !m.translatedText && !failedIds.has(m.id) && m.text);
    if (needTranslation.length === 0) return;

    translatingRef.current = true;
    const ids = needTranslation.map((m) => m.id);
    setTranslatingIds((prev) => {
      const next = new Set(prev);
      ids.forEach((id) => next.add(id));
      return next;
    });

    // Batch translate — parallel API calls, single atomic storage write
    const results = await store.translateMessages(chatRoomId, ids);

    const newFailed = new Set<string>();
    for (const id of ids) {
      if (results[id] === null || results[id] === undefined) {
        newFailed.add(id);
      }
    }

    setTranslatingIds(new Set());
    if (newFailed.size > 0) {
      setFailedIds((prev) => {
        const next = new Set(prev);
        newFailed.forEach((id) => next.add(id));
        return next;
      });
    }

    const updated = await store.getMessages(chatRoomId);
    setMessages(updated);
    translatingRef.current = false;
  }, [translateOn, chatRoomId, failedIds]);

  useEffect(() => {
    if (translateOn && messages.length > 0) {
      translatePending(messages);
    }
  }, [translateOn, messages.length]);

  const retryTranslation = async (msg: ChatMessage) => {
    if (!chatRoomId || translatingRef.current) return;
    setFailedIds((prev) => {
      const next = new Set(prev);
      next.delete(msg.id);
      return next;
    });
    setTranslatingIds((prev) => new Set(prev).add(msg.id));
    translatingRef.current = true;
    const results = await store.translateMessages(chatRoomId, [msg.id]);
    setTranslatingIds((prev) => {
      const next = new Set(prev);
      next.delete(msg.id);
      return next;
    });
    if (!results[msg.id]) {
      setFailedIds((prev) => new Set(prev).add(msg.id));
    }
    const updated = await store.getMessages(chatRoomId);
    setMessages(updated);
    translatingRef.current = false;
  };

  const handleSend = async () => {
    const text = input.trim();
    if (!text || !chatRoomId) return;
    setInput("");
    await store.sendMessage(chatRoomId, "doctor", text);
    await loadMessages();
    setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
  };

  const formatTime = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  const renderMessage = ({ item, index }: { item: ChatMessage; index: number }) => {
    const isMe = item.sender === "doctor";
    const prevMsg = index > 0 ? messages[index - 1] : null;
    const showDateHeader = !prevMsg ||
      new Date(item.timestamp).toDateString() !== new Date(prevMsg.timestamp).toDateString();

    return (
      <>
        {showDateHeader && (
          <View style={s.dateHeader}>
            <Text style={s.dateHeaderText}>
              {new Date(item.timestamp).toLocaleDateString(undefined, {
                weekday: "short", month: "short", day: "numeric",
              })}
            </Text>
          </View>
        )}
        <View style={[s.msgRow, isMe && s.msgRowMe]}>
          {!isMe && (
            <View style={s.msgAvatar}>
              <Text style={s.msgAvatarText}>{(patientName || "P")?.[0]}</Text>
            </View>
          )}
          <View style={[s.bubble, isMe ? s.bubbleMe : s.bubbleThem]}>
            {/* Original text */}
            <Text style={[s.bubbleText, isMe ? s.bubbleTextMe : s.bubbleTextThem]}>
              {item.text}
            </Text>

            {/* Translation (only when toggle is ON) */}
            {translateOn && (
              <>
                {translatingIds.has(item.id) ? (
                  <View style={s.translatingRow}>
                    <ActivityIndicator size="small" color={isMe ? "rgba(255,255,255,0.6)" : T.textSec} />
                    <Text style={[s.translatingText, isMe && { color: "rgba(255,255,255,0.5)" }]}>
                      Translating...
                    </Text>
                  </View>
                ) : failedIds.has(item.id) ? (
                  <TouchableOpacity onPress={() => retryTranslation(item)}>
                    <Text style={s.translationFailed}>Translation failed — tap to retry</Text>
                  </TouchableOpacity>
                ) : item.translatedText ? (
                  <>
                    <View style={[s.transDivider, isMe && { backgroundColor: "rgba(255,255,255,0.2)" }]} />
                    <Text style={[s.transText, isMe ? s.transTextMe : s.transTextThem]}>
                      {item.translatedText}
                    </Text>
                  </>
                ) : null}
              </>
            )}

            <Text style={s.timeText}>
              {formatTime(item.timestamp)}
            </Text>
          </View>
        </View>
      </>
    );
  };

  return (
    <KeyboardAvoidingView
      style={s.container}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      keyboardVerticalOffset={0}
    >
      {/* Header */}
      <LinearGradient colors={["#0f766e", "#134e4a"]} style={s.header}>
        <TouchableOpacity style={s.backBtn} onPress={() => router.back()} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
          <Text style={s.backArrow}>‹</Text>
        </TouchableOpacity>
        <View style={s.headerInfo}>
          <View style={s.headerAvatar}>
            <Text style={s.headerAvatarText}>{(patientName || "P")?.[0]}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={s.headerName} numberOfLines={1}>{patientName || "Patient"}</Text>
            <Text style={s.headerSub}>Patient</Text>
          </View>
        </View>
        {/* Translation Toggle */}
        <TouchableOpacity
          onPress={() => setTranslateOn(!translateOn)}
          style={[s.translateToggle, translateOn && s.translateToggleOn]}
        >
          <Text style={[s.translateToggleText, translateOn && s.translateToggleTextOn]}>
            {translateOn ? "Translate ON" : "Translate OFF"}
          </Text>
        </TouchableOpacity>
      </LinearGradient>

      {/* Messages */}
      <FlatList
        ref={flatListRef}
        data={messages}
        keyExtractor={(item) => item.id}
        renderItem={renderMessage}
        contentContainerStyle={s.messageList}
        showsVerticalScrollIndicator={false}
        style={s.messageArea}
        onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: false })}
        ListEmptyComponent={
          <View style={s.emptyChat}>
            <Text style={s.emptyChatIcon}>💬</Text>
            <Text style={s.emptyChatText}>
              Chat with {patientName || "the patient"}
            </Text>
            <Text style={s.emptyChatSub}>
              Answer questions about their treatment
            </Text>
          </View>
        }
      />

      {/* Quick Reply Chips */}
      {messages.length === 0 && (
        <View style={s.quickReplies}>
          {[
            "Hello! I'm happy to answer any questions.",
            "We can complete the treatment within your visit dates.",
            "Here's what I recommend for your case...",
          ].map((q) => (
            <TouchableOpacity
              key={q}
              style={s.quickChip}
              onPress={async () => {
                if (!chatRoomId) return;
                await store.sendMessage(chatRoomId, "doctor", q);
                await loadMessages();
                setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
              }}
            >
              <Text style={s.quickChipText}>{q}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      {/* Input Bar */}
      <View style={s.inputBar}>
        <TextInput
          style={s.textInput}
          placeholder="Type a message..."
          placeholderTextColor="#94a3b8"
          value={input}
          onChangeText={setInput}
          onSubmitEditing={handleSend}
          returnKeyType="send"
          multiline
          maxLength={1000}
        />
        <TouchableOpacity
          style={[s.sendBtn, !input.trim() && s.sendBtnDisabled]}
          onPress={handleSend}
          disabled={!input.trim()}
          activeOpacity={0.7}
        >
          <Text style={s.sendBtnText}>→</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: T.bg },

  header: {
    flexDirection: "row", alignItems: "center", gap: 12,
    paddingHorizontal: 16, paddingTop: 56, paddingBottom: 14,
  },
  backBtn: {
    width: 36, height: 36, borderRadius: 12,
    backgroundColor: "rgba(255,255,255,0.12)",
    borderWidth: 1, borderColor: "rgba(255,255,255,0.15)",
    alignItems: "center", justifyContent: "center",
  },
  backArrow: { fontSize: 24, color: "#fff", fontWeight: "600", marginTop: -2 },
  headerInfo: { flex: 1, flexDirection: "row", alignItems: "center", gap: 10 },
  headerAvatar: {
    width: 38, height: 38, borderRadius: 19,
    backgroundColor: "rgba(255,255,255,0.2)", alignItems: "center", justifyContent: "center",
  },
  headerAvatarText: { fontSize: 15, fontWeight: "700", color: T.white },
  headerName: { fontSize: 15, fontWeight: "700", color: T.white },
  headerSub: { fontSize: 11, color: "rgba(255,255,255,0.7)" },

  // Translation toggle (dark header variant)
  translateToggle: {
    borderRadius: 8, paddingHorizontal: 10, paddingVertical: 6,
    borderWidth: 1, borderColor: "rgba(255,255,255,0.3)", backgroundColor: "rgba(255,255,255,0.1)",
  },
  translateToggleOn: {
    backgroundColor: "rgba(255,255,255,0.25)", borderColor: "rgba(255,255,255,0.6)",
  },
  translateToggleText: {
    fontSize: 11, fontWeight: "600", color: "rgba(255,255,255,0.5)",
  },
  translateToggleTextOn: {
    color: T.white,
  },

  onlineDot: {
    width: 8, height: 8, borderRadius: 4, backgroundColor: "#22c55e",
  },

  messageArea: { flex: 1, backgroundColor: T.bg },
  messageList: { padding: 16, paddingBottom: 8, flexGrow: 1 },

  dateHeader: { alignItems: "center", marginVertical: 12 },
  dateHeaderText: {
    fontSize: 11, color: T.textMuted, fontWeight: "600",
    backgroundColor: "#f1f5f9", paddingHorizontal: 12, paddingVertical: 4,
    borderRadius: 10, overflow: "hidden",
  },

  msgRow: { flexDirection: "row", alignItems: "flex-end", marginBottom: 8, gap: 8 },
  msgRowMe: { flexDirection: "row-reverse" },

  msgAvatar: {
    width: 28, height: 28, borderRadius: 14,
    backgroundColor: "rgba(20,184,166,0.1)", alignItems: "center", justifyContent: "center",
  },
  msgAvatarText: { fontSize: 11, fontWeight: "700", color: T.teal },

  bubble: {
    maxWidth: "75%", borderRadius: 18, paddingHorizontal: 14, paddingVertical: 10,
  },
  bubbleMe: {
    backgroundColor: T.teal, borderBottomRightRadius: 4,
  },
  bubbleThem: {
    backgroundColor: "#f1f5f9", borderBottomLeftRadius: 4,
  },
  bubbleText: { fontSize: 14, lineHeight: 20 },
  bubbleTextMe: { color: T.white },
  bubbleTextThem: { color: T.text },
  timeText: { fontSize: 10, marginTop: 4, color: T.textMuted },

  // Translation bubble additions
  translatingRow: {
    flexDirection: "row", alignItems: "center", gap: 6, marginTop: 6,
  },
  translatingText: {
    fontSize: 12, color: T.textSec, fontStyle: "italic",
  },
  transDivider: {
    height: 1, backgroundColor: "rgba(0,0,0,0.08)", marginVertical: 6,
  },
  transText: {
    fontSize: 13, lineHeight: 18,
  },
  transTextMe: {
    color: "rgba(255,255,255,0.7)",
  },
  transTextThem: {
    color: T.textSec,
  },
  translationFailed: {
    fontSize: 12, color: "#ef4444", marginTop: 4,
  },

  emptyChat: { flex: 1, alignItems: "center", justifyContent: "center", paddingVertical: 60 },
  emptyChatIcon: { fontSize: 48, marginBottom: 12 },
  emptyChatText: { fontSize: 16, fontWeight: "600", color: T.text, marginBottom: 4 },
  emptyChatSub: { fontSize: 13, color: T.textSec, textAlign: "center" },

  quickReplies: { paddingHorizontal: 16, paddingBottom: 8, gap: 8 },
  quickChip: {
    backgroundColor: T.white, borderRadius: 20, paddingHorizontal: 16, paddingVertical: 10,
    borderWidth: 1, borderColor: T.border,
  },
  quickChipText: { fontSize: 13, color: T.teal },

  inputBar: {
    flexDirection: "row", alignItems: "flex-end", gap: 10,
    paddingHorizontal: 16, paddingVertical: 12, paddingBottom: 36,
    backgroundColor: T.white, borderTopWidth: 1, borderTopColor: T.border,
  },
  textInput: {
    flex: 1, backgroundColor: T.bg, borderRadius: 22, paddingHorizontal: 18,
    paddingVertical: 10, fontSize: 14, color: T.text, maxHeight: 100,
    borderWidth: 1, borderColor: T.border,
  },
  sendBtn: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: T.teal, alignItems: "center", justifyContent: "center",
  },
  sendBtnDisabled: { opacity: 0.4 },
  sendBtnText: { color: T.white, fontSize: 20, fontWeight: "600" },
});
